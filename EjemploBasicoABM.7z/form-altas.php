<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Formulario de Altas</title>
</head>
<body>

	<h3 style="text-align: center;">FORMULARIO DE ALTA</h3>
	<form action="altas.php" method="POST" >
		Apellido: <input type="text" name="apellido"><br>
		Nombre: <input type="text" name="nombre"><br>
		Edad: <input type="text" name="edad"><br>
		<input type="submit" value="Grabar"><br>
	</form>
	<a href="menu.php">Volver</a>
	
</body>
</html>