<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Menu general</title>
</head>
<body>
	<h3>MENU GENERAL</h3>
	
	<div style="text-align: center;">		
	
	<a href="form-altas.php">Alta</a><br>
	<a href="form-bajas.php">Bajas</a><br>
	<a href="form-modificacion.php">Modificaciones</a><br>
	<a href="listar.php">Listado de personas</a><br>

	</div>
	
</body>
</html>